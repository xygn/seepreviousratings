**If you are here to remove the "Card Rating History" label, change <i> Show Label </i> to "False"** 

To change the postion to the top of the card reviewers, change to "top" instead of "bottom". Horizontal adjustment is still a 
work in progress as it's super buggy. 

Credit goes to <b> gbrl.sc, cqg, Casartelli and korkmaz </b> for their suggestions and help in making this addon!
