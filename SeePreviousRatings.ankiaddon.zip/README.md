<h1 align = "center"> Card History At A Glance</h1>

<img width="1227" alt="Screen Shot 2021-07-30 at 3 33 10 PM" src="https://user-images.githubusercontent.com/46613983/127713601-b4cc0288-8cfe-4874-87f3-ba173bc9af49.png">

<img width="1420" alt="Screen Shot 2021-07-30 at 3 35 51 PM" src="https://user-images.githubusercontent.com/46613983/127714056-81c21512-2d43-47ae-ae92-fac1845be51e.png">

<p align = "center">
<img src = "https://user-images.githubusercontent.com/46613983/127709005-7ccb7806-2eb2-4f58-96ba-d259542512d1.gif"> 
</p>


Stop having to press card browser and ctrl+i for every card and then <strong>WINCING</strong> to see it's history of reviews
<strong> FEATURES </strong>
<ul> <li> Visualize previous card rating history in the reviewer at a glance. </li>
        <li> Hover over each review to see <strong> WHEN </strong> you reviewed it </li>
        <li> Immediately recognize which cards you struggle with and which cards you excel at. </li> 
        <li> Quickly get data on how often you have seen the card </li> </ul>
<i> Addon Idea by <a href="https://forums.ankiweb.net/t/display-card-ratings-in-the-verse-side/11625" rel="nofollow">gbrl.sc</a> on the Anki Forums.  </i>
